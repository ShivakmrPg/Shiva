# -*- coding: utf-8 -*-
# @Time    : 2020/10/17 09:41 AM
# @Author  : Shivakumara
# @File    : __init__.py
# @Software: Anaconda

import os
import re
import ntpath
import time
import openpyxl

def DeleteFile(Path):
    os.remove(Path)

def WaitInSeconds(Seconds):
    time.sleep(Seconds)
    
def GetTimeStampNs():
    return time.perf_counter_ns()

def GetCurrTime():
    return str(time.ctime())

def GetAllFiles(dirName):
    listOfFile = os.listdir(dirName)
    allFiles = list()
    for entry in listOfFile:
        fullPath = os.path.join(dirName, entry)
        if os.path.isdir(fullPath):
            allFiles = allFiles + GetAllFiles(fullPath)
        else:
            allFiles.append(fullPath)
    return allFiles

def OpenFileWithDefApp(Path):
    os.startfile(Path, 'open')
    
def GetFileNameFrmPath(Path):
    return ntpath.basename(Path)

def Remove_C_Comment(FilePath):
    CommentStart = 0
    CommentCount = 0
    ModText = ""
    InFileText = ""
    InFile = open(FilePath,"r")
    InFileTextList = InFile.readlines()
    InFile.close()
    OutFile = open(FilePath,"w+")
    for i in range(0,len(InFileTextList)):
        InFileText += InFileTextList[i]
    InFileText += "  "   
    for i in range(0,len(InFileText)-2):
        if(InFileText[i:(i+2)] == "/*"):
            if(CommentStart == 0):
                CommentStart |= 1
        if(InFileText[i:i+2] == "*/"):
            if(CommentStart != 0):
                CommentStart *= 0
                CommentCount += 3
        if(CommentStart == 0):
            if(CommentCount > 0):
                CommentCount -= 1
            if(CommentCount == 0):
                ModText += InFileText[i]
    ModText.replace(" \n","\n")               
    ModText.replace("\t\n","\n")                            
    OutFile.write(ModText)
    OutFile.close()

def SearchInExcelFile(Path,SearchNames):
    ExceLFile = Open_ReadExcelFile(Path) 
    TotalPages = ExceLFile.get_sheet_names() 
    GlobalText = ""
    for Page in TotalPages: 
        WSheet = ExceLFile.get_sheet_by_name(Page)
        for Col in range(1,WSheet.max_column):
            for Row in range(1,WSheet.max_row):
                for i in range(0,len(SearchNames)):
                    if(WSheet.cell(row = Row, column = Col).value == None):
                        break
                    if(SearchNames[i] in str(WSheet.cell(row = Row, column = Col).value)):
                        GlobalText += "Found " + SearchNames[i] + " in "+ str(WSheet) + str(Row)+" "+str(Col) + "\n"
                        break
    return GlobalText

def Open_ReadExcelFile(path):
    ExceLFile = openpyxl.load_workbook(path) 
    return ExceLFile

def CreateExcelSheet(Name):
    wb = openpyxl.Workbook()
    wb.save(Name + ".xlsx")

def WriteListToFile(List,Name):
    File1 = open(Name,"w+",encoding="utf-8")
    for line in List:
        File1.write(str(line)+"\n")
    File1.close()



def LookInFile(FileName,FileTypeList):
    for i in range(0,len(FileTypeList)):
        if(FileName.endswith(FileTypeList[i])):
            return True
    return False


def GetNormalizedText(Text,Length):
    while(len(Text) < Length):
        Text += " "
    return Text
        

def string_found(string1, string2):
   if re.search(r"\b" + re.escape(string1) + r"\b", string2):
      return True
   return False

def SearchinFolder(Source,SearchList,PrintLine = 0, StringFound = 0,    FileFound = 0,
    LineFound = 0,    StringFoundCtr = 0,
    FileFoundCtr = 0,    WriteText = "",
    FileText = "",    FileNames = "",
    MaxLength = 0,
    FileTypeList = [".c", ".h" ]):
    for i in range(0,len(SearchList)):
        if(MaxLength < len(SearchList[i])):
            MaxLength = len(SearchList[i])
    
    AllFiles = GetAllFiles(Source)
    LogFile = open("LogFile.txt","w+")
    StartTime = time.ctime()
    print(time.ctime())
    LogFile.write(str(StartTime)+"\n")
    
    for i in range(0,len(SearchList)):
        StringFound = 0
        StringFoundCtr = 0
        FileFoundCtr = 0 
        WriteText = ""
        for j in range(0,len(AllFiles)):
            if(LookInFile(AllFiles[j],FileTypeList)):
                TextFile = open(AllFiles[j],"r")
                ReadFileText = TextFile.readlines()
                LineFound = 0
                for k in range(0,len(ReadFileText)):
                    if(string_found(SearchList[i], ReadFileText[k])):
                        if(LineFound == 0):
                            LineFound = 1
                            StringFound = 1
                            WriteText += ntpath.basename(AllFiles[j])+" :\n"
                        StringFoundCtr += 1
                        if(PrintLine == 1):
                            WriteText += str(k) +"\t\t" + ReadFileText[k]
                if(LineFound == 1):
                    FileFoundCtr += 1
                    FileNames += ntpath.basename(AllFiles[j]) + "\t"
                    if(PrintLine == 1):
                        WriteText += "\n"
    
        if(StringFound == 1):  
                
            FileText += GetNormalizedText(SearchList[i],MaxLength)+"\t TotalFiles "+str(FileFoundCtr)+"\t"
            FileText += "TotalCount "+str(StringFoundCtr) + "\t"
            FileText += FileNames + "\n"
            FileNames = ""
            WriteText += SearchList[i]+"\t TotalCount "+str(StringFoundCtr)+"\n"
            WriteText += SearchList[i]+"\t TotalFiles "+str(FileFoundCtr)+"\n"
            WriteText += "-------------------------------------"
            WriteText += "-------------------------------------"
            WriteText += "-------------------------------------\n"
        if(PrintLine == 1):
            LogFile.write(WriteText)
        WriteText = ""
    #    if(i>3):
    #        break
        
    EndTime = time.ctime()
    print(time.ctime())
    LogFile.write("\n" + FileText + "\n")
    LogFile.write(str(EndTime))
    LogFile.close() 
    OpenFileWithDefApp("LogFile.txt")
